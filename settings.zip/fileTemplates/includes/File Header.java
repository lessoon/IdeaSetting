/**
 * <p>功能概述：</p>
 * <p>Date: ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}</p>
 * <p>Copyright: Copyright(c)$YEAR$ RedaFlight.com All Rights Reserved</p>
 *
 * @author      Lidu
 * @version     1.0
 * @since       JDK 1.7
 */